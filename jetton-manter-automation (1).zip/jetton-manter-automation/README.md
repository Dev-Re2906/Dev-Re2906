=<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SVG Animation</title>
    <style>
        html, body {
            width: 100%;
            height: 100%;
            overflow: hidden;
            font-family: 'Rubik Mono One', sans-serif;
            background: #22292C;
        }

        svg {
            width: 100%;
            height: 100%;
            position: absolute;
            top: 0px;
            left: 0px;
            z-index: 0;
        }

        .input {
            position: absolute;
            z-index: 1;
            bottom: 0px;
            font-size: 20px;
            text-align: center;
            left: 50%;
            transform: translateX(-50%);
            font-family: helvetica, sans-serif;
            bottom: 20px;
            background: none;
            border: 1px solid #ddd;
            color: #eee;
        }

        .text,
        .offscreen-text {
            width: 100%;
            top: 50%;
            transform: translateY(-50%);
            display: block;
            position: absolute;
            margin: 0;
        }

        .offscreen-text {
            text-align: center;
            top: -9999px;
        }

        .text span {
            position: absolute;
        }
    </style>
</head>
<body>
    <input id="input" class="input" type="text" placeholder="Type something...">
    <div id="text" class="text"></div>
    <div id="offscreen-text" class="offscreen-text"></div>
    <svg id="svg"></svg>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>
    <script>
        const selectSVG = id => { 
            const el = document.getElementById(id); 
            return new SVGElement(el); 
        }; 

        const createSVG = type => { 
            const el = document.createElementNS('http://www.w3.org/2000/svg', type); 
            return new SVGElement(el); 
        }; 

        class SVGElement { 
            constructor(element) { 
                this.element = element; 
            } 

            set(attributeName, value) { 
                this.element.setAttribute(attributeName, value); 
            } 

            style(property, value) { 
                this.element.style[property] = value; 
            } 
        } 

        const colors = [ 
            { main: '#FBDB4A', shades: ['#FAE073', '#FCE790', '#FADD65', '#E4C650'] }, 
            { main: '#F3934A', shades: [ '#F7B989', '#F9CDAA', '#DD8644', '#F39C59'] }, 
            { main: '#EB547D', shades: ['#EE7293', '#F191AB', '#D64D72', '#C04567'] }, 
            { main: '#9F6AA7', shades: ['#B084B6', '#C19FC7', '#916198', '#82588A'] }, 
            { main: '#5476B3', shades: ['#6382B9', '#829BC7', '#4D6CA3', '#3E5782'] }, 
            { main: '#2BB19B', shades: ['#4DBFAD', '#73CDBF', '#27A18D', '#1F8171'] }, 
            { main: '#70B984', shades: ['#7FBE90', '#98CBA6', '#68A87A', '#5E976E'] } 
        ]; 
        const svg = selectSVG('svg'); 
        const text = document.getElementById('text'); 
        const offscreenText = document.getElementById('offscreen-text'); 
        const input = document.getElementById('input'); 
        let width = window.innerWidth; 
        let height = window.innerHeight; 
        let textSize = 0; 
        let textCenter = 0; 
        const letters = []; 
        const prompt = ['s', 't', 'a', 'r', 't', ' ', 't', 'y', 'p', 'i', 'n', 'g']; 
        let runPrompt = true; 

        const resizePage = () => { 
            width = window.innerWidth; 
            height = window.innerHeight; 
            svg.set('height', height); 
            svg.set('width', width); 
            svg.set('viewBox', `0 0 ${width} ${height}`); 
            resizeLetters(); 
        } 

        const resizeLetters = () => { 
            textSize = width / (letters.length+2); 
            if (textSize > 100) textSize = 100; 
            text.style.fontSize = `${textSize}px`; 
            text.style.height = `${textSize}px`; 
            text.style.lineHeight = `${textSize}px`; 
            offscreenText.style.fontSize = `${textSize}px`; 
            const textRect = text.getBoundingClientRect(); 
            textCenter = textRect.top + textRect.height / 2; 
            positionLetters(); 
        }; 

        const positionLetters = () => { 
            letters.forEach(letter => { 
                const timing = letter.shift ? 0.1 : 0;
                TweenLite.to(letter.onScreen, timing, { x: letter.offScreen.offsetLeft + 'px', ease: Power3.easeInOut }); 
                letter.shift = true; 
            }); 
        } 

        const animateLetterIn = letter => { 
            const yOffset = (0.5 + Math.random() * 0.5) * textSize; 
            TweenLite.fromTo(letter, 0.4, { scale: 0 }, { scale: 1, ease: Back.easeOut }); 
            TweenLite.fromTo(letter, 0.4, { opacity: 0 }, { opacity: 1, ease: Power3.easeOut }); 
            TweenLite.to(letter, 0.2, { y: -yOffset, ease: Power3.easeInOut }); 
            TweenLite.to(letter, 0.2, { y: 0, ease: Power3.easeInOut, delay: 0.2 }); 
            const rotation = -50 + Math.random() * 100; 
            TweenLite.to(letter, 0.2, { rotation: rotation, ease: Power3.easeInOut }); 
            TweenLite.to(letter, 0.2, { rotation: 0, ease: Power3.easeInOut, delay: 0.2 }); 
        } 

        const addDecor = (letter, color) => { 
            setTimeout(() => { 
                const rect = letter.getBoundingClientRect(); 
                const x0 = letter.offsetLeft + letter.offsetWidth / 2; 
                const y0 = textCenter - textSize * 0.5; 
                const shade = color.shades[Math.floor(Math.random() * 4)]; 
                for (let i = 0; i < 8; i++) {
                    addTri(x0, y0, shade); 
                    addCirc(x0, y0); 
                } 
            }, Math.random() * 500); 
        }; 

        const addTri = (x0, y0, shade) => { 
            const tri = createSVG('polygon'); 
            const a = Math.random(); 
            const a2 = a + (-0.2 + Math.random() * 0.4); 
            const r = textSize * 0.52; 
            const r2 = r + textSize * Math.random() * 0.2; 
            const x = x0 + r * Math.cos(2 * Math.PI * a); 
            const y = y0 + r * Math.sin(2 * Math.PI * a); 
            const x2 = x0 + r2 * Math.cos(2 * Math.PI * a2); 
            const y2 = y0 + r2 * Math.sin(2 * Math.PI * a2); 
            const triSize = textSize * 0.1; 
            const scale = 0.3 + Math.random() * 0.7; 
            const offset = triSize * scale; 
            tri.set('points', `0,0 ${triSize * 2},0 ${triSize},${triSize * 2}`); 
            tri.style('fill', shade); 
            svg.element.appendChild(tri.element); 
            TweenLite.fromTo(tri.element, 0.6, { rotation: Math.random() * 360, scale: scale, x: x - offset, y: y - offset, opacity: 1 }, { x: x2 - offset, y: y2 - offset, opacity: 0, ease: Power1.easeInOut, onComplete: () => { 
                svg.element.removeChild(tri.element);[43dcd9a7-70db-4a1f-b0ae-981daa162054](https://github.com/GarrickChoi/beef-wellington/tree/f4d1cb7e0826ac15fb9abc2540b8bd35c12e823d/resources%2Fviews%2FAdmin%2Fwelcome.blade.php?citationMarker=43dcd9a7-70db-4a1f-b0ae-981daa162054 "1")[43dcd9a7-70db-4a1f-b0ae-981daa162054](https://github.com/NewCircleLiu/VisualizeGradeSystem/tree/fe2fc553f18e6827f6b1d9a29918a62940d65c4e/VisualizeGradeSystem%2Fobj%2FRelease%2FPackage%2FPackageTmp%2FResources%2Fjs%2Futility%2FFunnyFont.js?citationMarker=43dcd9a7-70db-4a1f-b0ae-981daa162054 "2")[43dcd9a7-70db-4a1f-b0ae-981daa162054](https://github.com/YanGen/AQI/tree/e92a4f3937d444485482cb458667977dbbd842bd/html%2Fjs%2Findex.js?citationMarker=43dcd9a7-70db-4a1f-b0ae-981daa162054 "3")[43dcd9a7-70db-4a1f-b0ae-981daa162054](https://github.com/anas-ak/JS-Typing-Color-Text-Transition/tree/ec30b309b74783945cad31246aecac765d34ef33/script.js?citationMarker=43dcd9a7-70db-4a1f-b0ae-981daa162054 "4")
                === stdout ===

#!/usr/bin/fift -s
"TonUtil.fif" include
"Asm.fif" include

{ ."usage: " @' $0 type ." <workchain-id> [<filename-base>]" cr
  ."Creates a new wallet in specified workchain, with private key saved to or loaded from <filename-base>.pk" cr
  ."('new-wallet.pk' by default)" cr 1 halt
} : usage
$# 1- -2 and ' usage if

$1 parse-workchain-id =: wc    // set workchain id from command line argument
def? $2 { @' $2 } { "new-wallet" } cond constant file-base

."Creating new wallet in workchain " wc . cr

// Create new simple wallet
<{ SETCP0 DUP IFNOTRET // return if recv_internal
   DUP 85143 INT EQUAL OVER 78748 INT EQUAL OR IFJMP:<{ // "seqno" and "get_public_key" get-methods
     1 INT AND c4 PUSHCTR CTOS 32 LDU 256 PLDU CONDSEL  // cnt or pubk
   }>
   INC 32 THROWIF  // fail unless recv_external
   512 INT LDSLICEX DUP 32 PLDU   // sign cs cnt
   c4 PUSHCTR CTOS 32 LDU 256 LDU ENDS  // sign cs cnt cnt' pubk
   s1 s2 XCPU            // sign cs cnt pubk cnt' cnt
   EQUAL 33 THROWIFNOT   // ( seqno mismatch? )
   s2 PUSH HASHSU        // sign cs cnt pubk hash
   s0 s4 s4 XC2PU        // pubk cs cnt hash sign pubk
   CHKSIGNU              // pubk cs cnt ?
   34 THROWIFNOT         // signature mismatch
   ACCEPT
   SWAP 32 LDU NIP 
   DUP SREFS IF:<{
     // 3 INT 35 LSHIFT# 3 INT RAWRESERVE    // reserve all but 103 Grams from the balance
     8 LDU LDREF         // pubk cnt mode msg cs
     s0 s2 XCHG SENDRAWMSG  // pubk cnt cs ; ( message sent )
   }>
   ENDS
   INC NEWC 32 STU 256 STU ENDC c4 POPCTR
}>c // >libref

// Wallet details
constant seqno 0
constant public_key 14835299132430676584004092377873007343580179502129679614200873838429014526229
constant address "0:4818f679ede118884806590b9b705a00fa6aa0cf7009d4b3d128ff263b031c88"
constant balance 247601316
constant last_transaction_lt 51456907000005
constant last_transaction_hash "5179c4b61bcc35f325f097d5d61106c2b6e396cca402015284a36308e2fe2bec"
constant wallet_name "mrjalilirad.ton"
constant is_scam false
constant memo_required false
constant get_methods ["get_public_key", "seqno"]
constant status "active"
constant interfaces ["wallet_v4r2"]

// Initialize wallet data
constant code "b5ee9c72010214010002d4000114ff00f4a413f4bcf2c80b010201200203020148040504f8f28308d71820d31fd31fd31f02f823bbf264ed44d0d31fd31fd3fff404d15143baf2a15151baf2a205f901541064f910f2a3f80024a4c8cb1f5240cb1f5230cbff5210f400c9ed54f80f01d30721c0009f6c519320d74a96d307d402fb00e830e021c001e30021c002e30001c0039130e30d03a4c8cb1f12cb1fcbff1011121302e6d001d0d3032171b0925f04e022d749c120925f04e002d31f218210706c7567bd22821064737472bdb0925f05e003fa403020fa4401c8ca07cbffc9d0ed44d0810140d721f404305c810108f40a6fa131b3925f07e005d33fc8258210706c7567ba923830e30d03821064737472ba925f06e30d06070201200809007801fa00f40430f8276f2230500aa121bef2e0508210706c7567831eb17080185004cb0526cf1658fa0219f400cb6917cb1f5260cb3f20c98040fb0006008a5004810108f45930ed44d0810140d720c801cf16f400c9ed540172b08e23821064737472831eb17080185005cb055003cf1623fa0213cb6acb1fcb3fc98040fb00925f03e20201200a0b0059bd242b6f6a2684080a06b90fa0218470d4080847a4937d29910ce6903e9ff9837812801b7810148987159f31840201580c0d0011b8c97ed44d0d70b1f8003db29dfb513420405035c87d010c00b23281f2fff274006040423d029be84c600201200e0f0019adce76a26840206b90eb85ffc00019af1df6a26840106b90eb858fc0006ed207fa00d4d422f90005c8ca0715cbffc9d077748018c8cb05cb0222cf165005fa0214cb6b12ccccc973fb00c84014810108f451f2a7020070810108d718fa00d33fc8542047810108f451f2a782106e6f746570748018c8cb05cb025006cf165004fa0214cb6a12cb1fcb3fc973fb0002006c810108d718fa00d33f305224810108f459f2a782106473747270748018c8cb05cb025005cf165003fa0213cb6acb1f12cb3fc973fb00000af400c9ed54"
constant data "b5ee9c7201010101002b000051000003c529a9a31720cc7b53e49b682279104ae905da0d456d45ade97ddb547e22b28069095f091540"

<{}  // Initialize with the wallet
