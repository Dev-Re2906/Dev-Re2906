func -o wallet-v4-code.fif -SPA stdlib.fc wallet-v4-code.fc
func -o subscription-plugin-code.fif -SPA stdlib.fc simple-subscription-plugin.fc

fift print-hex.fif